## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE-------------------------------------------------------
#  bot <- Bot(token = "TOKEN", request_config = httr::use_proxy(...))

## ---- eval = FALSE-------------------------------------------------------
#  updater <- Updater(token = "TOKEN", request_config = httr::use_proxy(...))

